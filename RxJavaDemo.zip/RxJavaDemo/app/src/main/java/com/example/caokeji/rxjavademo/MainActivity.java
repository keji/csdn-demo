package com.example.caokeji.rxjavademo;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class MainActivity extends Activity {
    private static final String TAG = "MainActivity";

    CompositeDisposable comDisposable = new CompositeDisposable();
    Bitmap bitmap;
    static ObservableOnSubscribe<String> observableOnSubscribe =
            new ObservableOnSubscribe<String>() {
                @Override
                public void subscribe(@NonNull ObservableEmitter<String> emitter) throws Exception {

                    while(true) {
                        try {
                            Thread.sleep(1000000);
                        }catch (Exception e){}
                        emitter.onNext("hello");
                    }
                }
            };

    static Consumer<String> consumer = new Consumer<String>() {

        @Override
        public void accept(@NonNull String s) throws Exception {
            Log.i(TAG,s);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Observable<String> observable = Observable.create(observableOnSubscribe).subscribeOn(Schedulers.io())
          .observeOn(AndroidSchedulers.mainThread())
          /*.onTerminateDetach()*/;
        Disposable disposable = observable.subscribe(/*new Consumer<String>() {
            @Override
            public void accept(@NonNull String s) throws Exception {
                Log.i(TAG,s);
            }
        }*/consumer);
        comDisposable.add(disposable);
        bitmap = BitmapFactory.decodeResource(getResources(),R.mipmap.aaa);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        comDisposable.dispose();
    }
}
