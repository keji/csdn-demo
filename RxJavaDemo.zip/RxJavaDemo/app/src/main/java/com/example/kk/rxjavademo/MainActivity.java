package com.example.kk.rxjavademo;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

public class MainActivity extends Activity {
    private static final String TAG = "MainActivity";

  /*  static ObservableOnSubscribe<String> observableOnSubscribe = new ObservableOnSubscribe<String>() {
        @Override
        public void subscribe(@NonNull ObservableEmitter<String> emitter) throws Exception {

            int num = 1000;
            while(num > 0) {
                try {
                    Thread.sleep(10000000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    Log.i(TAG, "thread interrupted");
                }
            }
            emitter.onNext("hello");
        }
    };*/

    CompositeDisposable comDisposable = new CompositeDisposable();
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ObservableOnSubscribe<String> observableOnSubscribe = new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(@NonNull ObservableEmitter<String> emitter) throws Exception {

              /*  int num = 1000;
                while(num > 0) {
                    try {
                        Thread.sleep(10000000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        Log.i(TAG, "thread interrupted");
                    }
                }*/
                emitter.onNext("hello");
            }
        };

        Observable<String> observable = Observable.create(observableOnSubscribe)
          .subscribeOn(Schedulers.io())
          .observeOn(AndroidSchedulers.mainThread())
          .onTerminateDetach()
          .map(new Function<String, String>() {
              @Override
              public String apply(@NonNull String s) throws Exception {
                  return s.trim();
              }
          })
          .onTerminateDetach();
        Disposable disposable = observable.subscribe(new Consumer<String>() {
            @Override
            public void accept(@NonNull String s) throws Exception {
                Log.i(TAG,s);
            }
        });
        comDisposable.add(disposable);
        bitmap = BitmapFactory.decodeResource(getResources(),R.mipmap.aaa);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        comDisposable.dispose();
    }
}
